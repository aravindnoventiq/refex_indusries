import { useState, useEffect } from 'react';
import { homeCmsApi } from '../../../services/api';
import { useScrollReveal } from '../../../hooks/useScrollReveal';
import { metaFor } from '../../../utils/businessMeta';

interface Business {
  id: number;
  title: string;
  description: string;
  image: string;
  link: string;
  order: number;
  isActive: boolean;
}

export default function BusinessSection() {
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [loading, setLoading] = useState(true);
  const revealRef = useScrollReveal<HTMLDivElement>({ deps: [businesses.length] });

  useEffect(() => {
    const fetchBusinesses = async () => {
      try {
        setLoading(true);
        const data = await homeCmsApi.getOfferings();
        // Map offerings to business structure
        const activeBusinesses = (data || [])
          .filter((item: any) => item.isActive)
          .map((item: any) => ({
            id: item.id,
            title: item.title,
            description: item.description,
            image: item.image || '',
            link: item.link || '/',
            order: item.order || 0,
            isActive: item.isActive,
          }))
          .sort((a: Business, b: Business) => (a.order || 0) - (b.order || 0));
        setBusinesses(activeBusinesses);
      } catch (error) {
        console.error('Failed to fetch businesses:', error);
        // Fallback to default data if API fails
        setBusinesses([
          {
            id: 1,
            title: 'Ash Utilization and Coal Handling',
            description: 'Providing end-to-end ash handling/disposal, coal yard management, and coal trading solutions for thermal power plants',
            image: 'https://static.readdy.ai/image/d0ead66ce635a168f1e83b108be94826/07455fbd11f25781b1c0645ed45ecceb.png',
            link: '/ash-utilization',
            order: 1,
            isActive: true,
          },
          {
            id: 2,
            title: 'Green Mobility',
            description: 'Offering tailored mobility services for corporate commuting and daily rides, with a focus on sustainability through electric four-wheeler fleets.',
            image: 'https://static.readdy.ai/image/d0ead66ce635a168f1e83b108be94826/71f2b6479f74d24cab18fe163beff0f1.png',
            link: '/green-mobility',
            order: 2,
            isActive: true,
          },
          {
            id: 3,
            title: 'Venwind Refex',
            description: 'Aiming to drive sustainable wind energy adoption nationwide with advanced 5.3 MW wind turbine manufacturing in India',
            image: 'https://static.readdy.ai/image/d0ead66ce635a168f1e83b108be94826/14ac7f1fbbb4c730f253c0cc8078f920.png',
            link: '/venwind-refex',
            order: 3,
            isActive: true,
          },
          {
            id: 4,
            title: 'Refrigerant Gas',
            description: 'A leading global supplier specializing in eco-friendly refrigerant gases, equipped with automated filling, rigorous quality control, and certified storage facilities',
            image: 'https://static.readdy.ai/image/d0ead66ce635a168f1e83b108be94826/a8311a97127f77813e6f7198f947d66c.png',
            link: '/refrigerant-gas',
            order: 4,
            isActive: true,
          },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchBusinesses();
  }, []);

  if (loading) {
    return (
      <section className="py-20 lg:py-28 bg-[#f7f7f7] relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              <p className="mt-4 text-gray-600">Loading businesses...</p>
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (businesses.length === 0) {
    return null;
  }

  const [featured, ...rest] = businesses;
  const featuredMeta = metaFor(featured.title);

  return (
    <section className="py-20 lg:py-28 bg-[#f7f7f7] relative overflow-hidden">
      <img
        src="https://refex.co.in/wp-content/uploads/2024/02/shape_img_new.png"
        alt=""
        className="absolute top-0 right-0 w-80 lg:w-[640px] opacity-10 pointer-events-none"
      />

      <div ref={revealRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 mb-12 lg:mb-16">
          <div>
            <span className="inline-block text-xs font-semibold tracking-[0.2em] uppercase text-[#7cd144] mb-4">
              What We Do
            </span>
            <h2 className="text-3xl lg:text-5xl font-bold text-[#1a1a1a] leading-tight">
              Our Businesses
            </h2>
          </div>
          <p className="text-gray-600 max-w-md leading-relaxed">
            {businesses.length} verticals united by one mission — building a cleaner,
            more sustainable future for India's core industries.
          </p>
        </div>

        {/* Featured business */}
        <a
          href={featured.link}
          className="group relative block overflow-hidden rounded-3xl h-[420px] lg:h-[520px] mb-6 shadow-lg hover:shadow-2xl transition-shadow duration-500"
        >
          <img
            src={featured.image}
            alt={featured.title}
            className="absolute inset-0 w-full h-full object-cover object-center transition-transform duration-[1200ms] ease-out group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-black/10" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-transparent to-transparent" />

          <span
            className="absolute top-8 right-8 lg:top-10 lg:right-10 text-[8rem] lg:text-[11rem] font-bold leading-none text-white/10 select-none"
            aria-hidden="true"
          >
            01
          </span>

          <div className="relative z-10 h-full flex flex-col justify-end p-8 lg:p-14 max-w-2xl">
            <span
              className="inline-flex w-fit items-center text-xs font-semibold tracking-[0.2em] uppercase px-3 py-1 rounded-full border mb-5"
              style={{ color: featuredMeta.accent, borderColor: featuredMeta.accent }}
            >
              {featuredMeta.tag}
            </span>
            <h3 className="text-2xl lg:text-4xl font-bold text-white mb-4 leading-tight">
              {featured.title}
            </h3>
            <p className="text-white/80 text-sm lg:text-base leading-relaxed mb-7 max-w-xl">
              {featured.description}
            </p>
            <span
              className="inline-flex items-center gap-2 w-fit px-6 py-3 rounded-full font-semibold text-sm transition-all duration-300 group-hover:gap-3"
              style={{ backgroundColor: featuredMeta.accent, color: '#0a0a0a' }}
            >
              Explore
              <i className="ri-arrow-right-line transition-transform duration-300 group-hover:translate-x-1"></i>
            </span>
          </div>
        </a>

        {/* Remaining businesses */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {rest.map((business, index) => {
            const meta = metaFor(business.title);
            return (
              <a
                key={business.id}
                href={business.link}
                className="group relative block overflow-hidden rounded-2xl h-[380px] shadow-md hover:shadow-2xl hover:-translate-y-1 transition-all duration-500"
              >
                <img
                  src={business.image}
                  alt={business.title}
                  className="absolute inset-0 w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/55 to-black/10" />

                <span
                  className="absolute top-5 right-5 text-5xl font-bold leading-none text-white/10 select-none"
                  aria-hidden="true"
                >
                  0{index + 2}
                </span>

                <div className="relative z-10 h-full flex flex-col justify-end p-6">
                  <span
                    className="inline-flex w-fit items-center text-[10px] font-semibold tracking-[0.2em] uppercase px-2.5 py-1 rounded-full border mb-4"
                    style={{ color: meta.accent, borderColor: meta.accent }}
                  >
                    {meta.tag}
                  </span>
                  <h3 className="text-lg lg:text-xl font-bold text-white mb-2 leading-tight">
                    {business.title}
                  </h3>
                  <p className="text-xs lg:text-sm text-white/75 mb-5 leading-relaxed line-clamp-2">
                    {business.description}
                  </p>
                  <span
                    className="inline-flex items-center gap-1.5 text-sm font-semibold transition-all duration-300 group-hover:gap-2.5"
                    style={{ color: meta.accent }}
                  >
                    Explore
                    <i className="ri-arrow-right-line transition-transform duration-300 group-hover:translate-x-1"></i>
                  </span>
                </div>
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
}
