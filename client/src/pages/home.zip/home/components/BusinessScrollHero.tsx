import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { homeCmsApi } from '../../../services/api';
import { metaFor } from '../../../utils/businessMeta';

gsap.registerPlugin(ScrollTrigger);

interface HeroSlide {
  id: number;
  title: string;
  image: string;
  order: number;
  isActive: boolean;
}

const BLEND = 0.3;

export default function BusinessScrollHero() {
  const [slides, setSlides] = useState<HeroSlide[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeIndex, setActiveIndex] = useState(0);

  const wrapperRef = useRef<HTMLElement | null>(null);
  const pinRef = useRef<HTMLDivElement | null>(null);
  const layerRefs = useRef<Array<HTMLDivElement | null>>([]);
  const imgRefs = useRef<Array<HTMLDivElement | null>>([]);
  const textRefs = useRef<Array<HTMLDivElement | null>>([]);
  const cueRef = useRef<HTMLDivElement | null>(null);
  const triggerRef = useRef<ScrollTrigger | null>(null);
  const activeIndexRef = useRef(0);

  useEffect(() => {
    const fetchSlides = async () => {
      try {
        setLoading(true);
        const data = await homeCmsApi.getSlides();
        const activeSlides = (data || [])
          .filter((slide: HeroSlide) => slide.isActive)
          .sort((a: HeroSlide, b: HeroSlide) => (a.order || 0) - (b.order || 0));
        setSlides(activeSlides);
      } catch (error) {
        console.error('Failed to fetch hero slides:', error);
        setSlides([
          {
            id: 1,
            title: 'Ash Utilization And Coal Handling',
            image: '/images/hero/ash-coal-night.png',
            order: 1,
            isActive: true,
          },
          {
            id: 2,
            title: 'Green Mobility',
            image: 'https://static.readdy.ai/image/d0ead66ce635a168f1e83b108be94826/71f2b6479f74d24cab18fe163beff0f1.png',
            order: 2,
            isActive: true,
          },
          {
            id: 3,
            title: 'Venwind Refex',
            image: '/images/hero/venwind-day.png',
            order: 3,
            isActive: true,
          },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchSlides();
  }, []);

  useEffect(() => {
    const N = slides.length;
    if (N === 0 || !wrapperRef.current || !pinRef.current) return;

    const ctx = gsap.context(() => {
      const st = ScrollTrigger.create({
        trigger: wrapperRef.current,
        start: 'top top',
        end: 'bottom bottom',
        scrub: 0.6,
        onUpdate: (self) => {
          const scaled = self.progress * N;
          const idx = Math.min(N - 1, Math.floor(scaled));
          const local = scaled - idx;

          layerRefs.current.forEach((layer, i) => {
            if (!layer) return;
            let opacity = 0;
            if (i === idx) {
              opacity = local < BLEND ? local / BLEND : 1;
            } else if (i === idx - 1 && local < BLEND) {
              opacity = 1 - local / BLEND;
            }
            gsap.set(layer, { opacity });
            const textEl = textRefs.current[i];
            if (textEl) {
              gsap.set(textEl, { opacity, y: (1 - opacity) * 24 });
            }
          });

          if (cueRef.current) {
            const cueOpacity = self.progress < 0.04 ? 1 - self.progress / 0.04 : 0;
            gsap.set(cueRef.current, {
              opacity: cueOpacity,
              pointerEvents: cueOpacity > 0 ? 'auto' : 'none',
            });
          }

          if (idx !== activeIndexRef.current) {
            activeIndexRef.current = idx;
            setActiveIndex(idx);
          }
        },
      });

      triggerRef.current = st;

      // Make sure first panel is visible before any scroll happens, and
      // hand the background zoom to GSAP so it's preserved once mousemove
      // starts writing xPercent/yPercent to the same transform.
      layerRefs.current.forEach((layer, i) => {
        if (layer) gsap.set(layer, { opacity: i === 0 ? 1 : 0 });
      });
      gsap.set(imgRefs.current, { scale: 1.1 });
      if (textRefs.current[0]) gsap.set(textRefs.current[0], { opacity: 1, y: 0 });
      if (cueRef.current) gsap.set(cueRef.current, { opacity: 1 });
    }, wrapperRef);

    const handleMouseMove = (e: MouseEvent) => {
      const pin = pinRef.current;
      if (!pin) return;
      const rect = pin.getBoundingClientRect();
      const nx = (e.clientX - rect.left) / rect.width - 0.5;
      const ny = (e.clientY - rect.top) / rect.height - 0.5;
      const activeImg = imgRefs.current[activeIndexRef.current];
      if (activeImg) {
        gsap.to(activeImg, {
          xPercent: nx * 6,
          yPercent: ny * 6,
          duration: 0.9,
          ease: 'power3.out',
          overwrite: 'auto',
        });
      }
    };
    pinRef.current.addEventListener('mousemove', handleMouseMove);

    return () => {
      pinRef.current?.removeEventListener('mousemove', handleMouseMove);
      ctx.revert();
    };
  }, [slides]);

  const scrollToPanel = (index: number) => {
    const st = triggerRef.current;
    const N = slides.length;
    if (!st || N === 0) return;
    const fraction = (index + 0.5) / N;
    const y = st.start + fraction * (st.end - st.start);
    window.scrollTo({ top: y, behavior: 'smooth' });
  };

  if (loading) {
    return (
      <section className="relative mt-32 h-[calc(100vh-8rem)] overflow-hidden bg-[#05070a] flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          <p className="mt-4 text-white/60">Loading...</p>
        </div>
      </section>
    );
  }

  if (slides.length === 0) {
    return null;
  }

  const N = slides.length;

  return (
    <section ref={wrapperRef} className="relative" style={{ height: `${N * 100}vh` }}>
      <div
        ref={pinRef}
        className="sticky top-32 h-[calc(100vh-8rem)] w-full overflow-hidden bg-[#05070a]"
      >
        {/* subtle tech grid texture */}
        <div
          className="absolute inset-0 z-[1] opacity-[0.07] pointer-events-none"
          style={{
            backgroundImage:
              'linear-gradient(rgba(255,255,255,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.6) 1px, transparent 1px)',
            backgroundSize: '48px 48px',
          }}
        />

        {slides.map((slide, i) => {
          const meta = metaFor(slide.title);
          return (
            <div
              key={slide.id}
              ref={(el) => {
                layerRefs.current[i] = el;
              }}
              className="absolute inset-0"
              style={{ opacity: i === 0 ? 1 : 0 }}
            >
              <div
                ref={(el) => {
                  imgRefs.current[i] = el;
                }}
                className="absolute inset-0"
              >
                <img
                  src={slide.image}
                  alt={slide.title}
                  className="w-full h-full object-cover object-center brightness-95 contrast-105"
                  draggable={false}
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-[#05070a] via-[#05070a]/45 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-r from-[#05070a]/65 via-transparent to-transparent" />

              <div className="relative z-10 h-full max-w-7xl mx-auto pl-4 pr-14 sm:px-6 lg:px-8 flex flex-col justify-end pb-20 lg:pb-28">
                <div
                  ref={(el) => {
                    textRefs.current[i] = el;
                  }}
                  className="max-w-2xl"
                  style={{ opacity: i === 0 ? 1 : 0 }}
                >
                  <div className="flex items-center gap-3 mb-5">
                    <span
                      className="text-xs font-semibold tracking-[0.2em] uppercase px-3 py-1 rounded-full border"
                      style={{ color: meta.accent, borderColor: meta.accent }}
                    >
                      {meta.tag}
                    </span>
                    <span className="text-white/40 text-xs tracking-widest font-mono">
                      0{i + 1} / 0{N}
                    </span>
                  </div>
                  <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-white leading-[1.05] mb-6">
                    {slide.title}
                  </h1>
                  <p className="text-white/70 text-base lg:text-lg leading-relaxed mb-8 max-w-xl">
                    {meta.description}
                  </p>
                  <a
                    href={meta.href}
                    className="inline-flex items-center gap-2 px-7 py-3 rounded-full font-semibold text-[#05070a] transition-transform duration-300 hover:scale-105"
                    style={{ backgroundColor: meta.accent }}
                  >
                    Explore
                    <i className="ri-arrow-right-line"></i>
                  </a>
                </div>
              </div>
            </div>
          );
        })}

        {/* progress rail */}
        {N > 1 && (
          <div className="absolute right-6 lg:right-10 top-1/2 -translate-y-1/2 z-20 flex flex-col items-center gap-4">
            {slides.map((slide, i) => (
              <button
                key={slide.id}
                aria-label={`Go to ${slide.title}`}
                onClick={() => scrollToPanel(i)}
                className="group flex items-center"
              >
                <span
                  className={`block rounded-full transition-all duration-300 ${
                    i === activeIndex ? 'w-3 h-3 bg-white' : 'w-2 h-2 bg-white/30 group-hover:bg-white/60'
                  }`}
                />
              </button>
            ))}
          </div>
        )}

        {/* scroll cue */}
        <div
          ref={cueRef}
          className="absolute top-8 left-1/2 -translate-x-1/2 z-20"
        >
          <span className="text-xs tracking-[0.3em] uppercase text-white/60 font-mono animate-pulse">
            Scroll to Explore
          </span>
        </div>
      </div>
    </section>
  );
}
