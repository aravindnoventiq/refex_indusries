import { useState, useEffect, useRef, useCallback } from 'react';
import { homeCmsApi } from '../../../services/api';
import { useScrollReveal } from '../../../hooks/useScrollReveal';

interface Award {
  id: number;
  title: string;
  image: string;
  order: number;
  isActive: boolean;
}

export default function AwardsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [awards, setAwards] = useState<Award[]>([]);
  const [loading, setLoading] = useState(true);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [transitionDuration, setTransitionDuration] = useState(500);
  const [itemWidth, setItemWidth] = useState(350);
  const autoPlayRef = useRef<NodeJS.Timeout | null>(null);
  const revealRef = useScrollReveal<HTMLDivElement>({ deps: [awards.length] });

  useEffect(() => {
    const fetchAwards = async () => {
      try {
        setLoading(true);
        const data = await homeCmsApi.getAwards();
        const activeAwards = (data || [])
          .filter((item: Award) => item.isActive)
          .sort((a: Award, b: Award) => (a.order || 0) - (b.order || 0));
        setAwards(activeAwards);
      } catch (error) {
        console.error('Failed to fetch awards:', error);
        // Fallback to default data if API fails
        setAwards([
          {
            id: 1,
            title: 'Best Organisations for Women 2024 Award by ET Now',
            image: 'https://refex.co.in/wp-content/uploads/2024/11/BEST-ORGANISATIONS-FOR-WOMEN-2024-With-Work-force-1-300x281-1.png',
            order: 1,
            isActive: true,
          },
          {
            id: 2,
            title: 'Most Diversified Sustainable Company (India) by The Business Concept. UK',
            image: 'https://refex.co.in/wp-content/uploads/2024/11/ESG_CSR_Award_01-Medium-300x295-1.png',
            order: 2,
            isActive: true,
          },
          {
            id: 3,
            title: 'Bronze Prize of Asia\'s Best Integrated Report for our First-ever Sustainability Report by AIRA',
            image: 'https://refex.co.in/wp-content/uploads/2024/11/Sustainability-report-award-Medium-300x225-1.png',
            order: 3,
            isActive: true,
          },
          {
            id: 4,
            title: 'GOLD STEVIE AWARD WINNER Conglomerates Category (Medium Size)',
            image: 'https://refex.co.in/wp-content/uploads/2024/11/Gold-Stieve-Refex.png',
            order: 4,
            isActive: true,
          },
          {
            id: 5,
            title: 'International Green Apple Environment Award 2024',
            image: 'https://refex.co.in/wp-content/uploads/2025/02/green-apple-award01.png',
            order: 5,
            isActive: true,
          },
          {
            id: 6,
            title: 'Best Waste Management Solution Award',
            image: 'https://refex.co.in/wp-content/uploads/2025/02/waste-managemnet-award01.png',
            order: 6,
            isActive: true,
          },
          {
            id: 7,
            title: 'ESG Excellence Award by ESG Grit Awards',
            image: 'https://refex.co.in/wp-content/uploads/2025/02/esg-excellence-award01.png',
            order: 7,
            isActive: true,
          },
          {
            id: 8,
            title: 'Great Place to Work Certified Apr 2025 - Apr 2026 India',
            image: 'https://refex.co.in/wp-content/uploads/2025/06/GPTW-award-img.png',
            order: 8,
            isActive: true,
          },
          {
            id: 9,
            title: 'Most Preferred Workplace 2025-2026 by Marksmen Daily',
            image: 'https://refex.co.in/wp-content/uploads/2025/07/award-img-1.png',
            order: 9,
            isActive: true,
          },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchAwards();
  }, []);

  // Calculate item width based on screen size
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 640) {
        setItemWidth(250);
      } else if (window.innerWidth < 768) {
        setItemWidth(280);
      } else if (window.innerWidth < 1024) {
        setItemWidth(320);
      } else {
        setItemWidth(350);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Navigate to next slide (move by 3 items)
  const goToNext = useCallback(() => {
    if (isTransitioning || awards.length === 0) return;
    setIsTransitioning(true);
    const itemsPerView = 3;
    const maxIndex = Math.max(0, awards.length - itemsPerView);
    const isLastGroup = currentIndex >= maxIndex;
    // Extra time when looping from last to first
    const duration = isLastGroup ? 1000 : 500;
    setTransitionDuration(duration);
    setCurrentIndex((prev) => {
      if (prev >= maxIndex) {
        return 0; // Loop back to start
      }
      return Math.min(prev + itemsPerView, maxIndex);
    });
    setTimeout(() => setIsTransitioning(false), duration);
  }, [isTransitioning, awards.length, currentIndex]);

  // Navigate to specific slide
  const goToSlide = useCallback((index: number) => {
    if (isTransitioning || index === currentIndex) return;
    setIsTransitioning(true);
    setTransitionDuration(500);
    setCurrentIndex(index);
    setTimeout(() => setIsTransitioning(false), 500);
  }, [isTransitioning, currentIndex]);

  // Navigate to previous group of items
  const goToPrev = useCallback(() => {
    if (isTransitioning || awards.length === 0) return;
    setIsTransitioning(true);
    const itemsPerView = 3;
    const maxIndex = Math.max(0, awards.length - itemsPerView);
    const isFirstGroup = currentIndex <= 0;
    const duration = isFirstGroup ? 1000 : 500;
    setTransitionDuration(duration);
    setCurrentIndex((prev) => {
      if (prev <= 0) return maxIndex;
      return Math.max(prev - itemsPerView, 0);
    });
    setTimeout(() => setIsTransitioning(false), duration);
  }, [isTransitioning, awards.length, currentIndex]);

  // Auto-play functionality
  useEffect(() => {
    if (awards.length === 0) return;

    const startAutoPlay = () => {
      autoPlayRef.current = setInterval(() => {
        goToNext();
      }, 4000);
    };

    startAutoPlay();

    return () => {
      if (autoPlayRef.current) {
        clearInterval(autoPlayRef.current);
      }
    };
  }, [awards.length, goToNext]);

  // Pause auto-play on hover
  const handleMouseEnter = () => {
    if (autoPlayRef.current) {
      clearInterval(autoPlayRef.current);
    }
  };

  const handleMouseLeave = () => {
    if (awards.length === 0) return;
    autoPlayRef.current = setInterval(() => {
      goToNext();
    }, 4000);
  };

  // Calculate the offset to show 3 items per row
  const getTransformOffset = () => {
    if (awards.length === 0) return 0;
    const gap = 32; // gap between items (gap-8 = 2rem = 32px)
    const totalItemWidth = itemWidth + gap;
    
    // Calculate the position to show currentIndex and next 2 items (3 total)
    const translateX = -(currentIndex * totalItemWidth);
    
    return translateX;
  };


  if (loading) {
    return (
      <section className="py-20 lg:py-28 bg-[#f7f7f7]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              <p className="mt-4 text-gray-600">Loading awards...</p>
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (awards.length === 0) {
    return null;
  }

  const itemsPerView = 3;
  const totalGroups = Math.ceil(awards.length / itemsPerView);

  return (
    <section className="py-20 lg:py-28 bg-[#f7f7f7] overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={revealRef} className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6 mb-12">
          <div>
            <span className="inline-block text-xs font-semibold tracking-[0.2em] uppercase text-[#7cd144] mb-4">
              Recognition
            </span>
            <h2 className="text-3xl lg:text-5xl font-bold text-[#1a1a1a] leading-tight mb-4">
              Awards & Accolades
            </h2>
            <p className="text-gray-600 max-w-xl">
              Our excellence is recognized through various awards and accolades that celebrate our achievements in quality and innovation.
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={goToPrev}
              aria-label="Previous"
              className="w-11 h-11 flex items-center justify-center rounded-full border border-gray-300 text-gray-500 hover:border-[#7cd144] hover:text-[#7cd144] transition-colors bg-white"
            >
              <i className="ri-arrow-left-line"></i>
            </button>
            <button
              onClick={goToNext}
              aria-label="Next"
              className="w-11 h-11 flex items-center justify-center rounded-full border border-gray-300 text-gray-500 hover:border-[#7cd144] hover:text-[#7cd144] transition-colors bg-white"
            >
              <i className="ri-arrow-right-line"></i>
            </button>
          </div>
        </div>

        <div
          className="relative"
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        >
          {/* Slider Container */}
          <div
            className="overflow-hidden mx-auto"
            style={{
              width: `${3 * (itemWidth + 32) - 32}px`, // Width for exactly 3 items (3 items + 2 gaps)
              maxWidth: '100%',
            }}
          >
            <div
              className="flex gap-8 ease-out"
              style={{
                transform: `translateX(${getTransformOffset()}px)`,
                transition: `transform ${transitionDuration}ms ease-out`,
                width: `${awards.length * (itemWidth + 32)}px`, // Total width for all items
              }}
            >
              {awards.map((award, index) => (
                <div
                  key={award.id}
                  className="flex-shrink-0 transition-all duration-500 group cursor-pointer"
                  style={{
                    width: `${itemWidth}px`,
                  }}
                  onClick={() => goToSlide(index)}
                >
                  <div className="h-full flex flex-col items-center text-center bg-white rounded-2xl shadow-md hover:shadow-2xl hover:-translate-y-1 transition-all duration-500 p-6 border border-gray-100">
                    <div className="mb-6 h-40 w-full flex items-center justify-center relative overflow-hidden rounded-lg">
                      <img
                        src={award.image}
                        alt={award.title}
                        className="max-h-full max-w-full object-contain transition-transform duration-500 group-hover:scale-105"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://via.placeholder.com/300x200?text=No+Image';
                        }}
                      />
                    </div>
                    <p className="text-gray-700 text-sm leading-relaxed group-hover:text-[#7cd144] transition-colors">
                      {award.title}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pagination Dots - Show dots for groups of 3 */}
          <div className="flex justify-center gap-2 mt-10">
            {Array.from({ length: totalGroups }).map((_, groupIndex) => {
              const groupStartIndex = groupIndex * itemsPerView;
              const isActive = currentIndex >= groupStartIndex && currentIndex < groupStartIndex + itemsPerView;

              return (
                <button
                  key={groupIndex}
                  onClick={() => goToSlide(groupStartIndex)}
                  className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                    isActive
                      ? 'w-8 bg-[#7cd144]'
                      : 'w-1.5 bg-gray-300 hover:bg-gray-400'
                  }`}
                  aria-label={`Go to group ${groupIndex + 1}`}
                />
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
