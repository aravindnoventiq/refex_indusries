import { useState, useEffect } from 'react';
import { aboutCmsApi } from '../../../services/api';
import { useScrollReveal } from '../../../hooks/useScrollReveal';

interface AboutSectionData {
  id: number;
  title: string;
  content: string;
  icon?: string;
  color?: string;
  order: number;
  isActive: boolean;
}

export default function AboutSection() {
  const [section, setSection] = useState<AboutSectionData | null>(null);
  const [loading, setLoading] = useState(true);
  const revealRef = useScrollReveal<HTMLDivElement>({ deps: [section] });

  useEffect(() => {
    const fetchSection = async () => {
      try {
        setLoading(true);
        const data = await aboutCmsApi.getSections();
        // Get the first active section, sorted by order
        const activeSection = (data || [])
          .filter((s: AboutSectionData) => s.isActive)
          .sort((a: AboutSectionData, b: AboutSectionData) => (a.order || 0) - (b.order || 0))[0];
        setSection(activeSection || null);
      } catch (error) {
        console.error('Failed to fetch about section:', error);
        // Fallback to default content if API fails
        setSection({
          id: 0,
          title: 'ABOUT US',
          content: 'Refex Industries Limited is a dynamic, diversified enterprise with strategic interests in refrigerant gases, coal and ash management, power trading, clean mobility, and renewable energy. We are committed to sustainability, innovation, and long-term value creation across sectors critical to India\'s growth.',
          color: '#7abc43',
          order: 1,
          isActive: true,
        });
      } finally {
        setLoading(false);
      }
    };

    fetchSection();
  }, []);

  if (loading) {
    return (
      <section className="py-20 lg:py-28 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center">
            <div className="text-center">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (!section) {
    return null;
  }

  const buttonColor = section.color || '#7abc43';

  return (
    <section className="py-20 lg:py-28 bg-gray-50 relative overflow-hidden">
      <span
        className="absolute -top-10 -left-6 lg:left-0 text-[10rem] lg:text-[16rem] font-bold leading-none text-black/[0.03] select-none pointer-events-none"
        aria-hidden="true"
      >
        "
      </span>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div ref={revealRef} className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16">
          <div className="lg:col-span-5">
            <span
              className="inline-block text-xs font-semibold tracking-[0.2em] uppercase mb-4"
              style={{ color: buttonColor }}
            >
              Who We Are
            </span>
            <h2 className="text-3xl lg:text-5xl font-bold text-gray-900 leading-tight">
              {section.title}
            </h2>
            <span
              className="block w-16 h-1 rounded-full mt-6"
              style={{ backgroundColor: buttonColor }}
            />
          </div>

          <div className="lg:col-span-7 flex flex-col justify-center">
            <p className="text-gray-600 text-lg lg:text-xl leading-relaxed mb-8">
              {section.content}
            </p>
            <div>
              <a
                href="/about-us"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full font-semibold transition-all duration-300 cursor-pointer whitespace-nowrap group hover:gap-3 hover:shadow-lg"
                style={{ backgroundColor: buttonColor, color: '#0a0a0a' }}
              >
                Discover More
                <i className="ri-arrow-right-line transition-transform duration-300 group-hover:translate-x-1"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
